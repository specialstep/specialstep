import React, { useState } from "react";
import { FaSearch, FaShoppingCart } from "react-icons/fa";
import { BrowserRouter as Router, Route, Routes, Link } from "react-router-dom";

const categories = ["جميع الأحذية", "رياضي", "كاجوال", "رسمي"];

const products = [
  { id: 1, name: "حذاء رياضي", category: "رياضي", price: "120 ريال", image: "https://via.placeholder.com/150", description: "حذاء رياضي مريح وخفيف الوزن مناسب للجري والتمارين الرياضية.", rating: 4.5 },
  { id: 2, name: "حذاء كاجوال", category: "كاجوال", price: "150 ريال", image: "https://via.placeholder.com/150", description: "حذاء كاجوال أنيق يناسب جميع الإطلالات اليومية.", rating: 4.2 },
  { id: 3, name: "حذاء رسمي", category: "رسمي", price: "200 ريال", image: "https://via.placeholder.com/150", description: "حذاء رسمي فاخر مصنوع من الجلد الطبيعي لمظهر أنيق.", rating: 4.8 },
];

const ProductDetails = ({ product }) => {
  if (!product) return <h2 className="text-center mt-10">لم يتم العثور على المنتج</h2>;

  return (
    <div className="min-h-screen bg-blue-900 text-white flex flex-col items-center p-6">
      <img src={product.image} alt={product.name} className="w-64 h-64 object-cover rounded-md" />
      <h2 className="text-3xl font-bold mt-4">{product.name}</h2>
      <p className="text-blue-300 text-xl font-semibold mt-2">{product.price}</p>
      <p className="text-blue-200 mt-2">{product.description}</p>
      <p className="text-yellow-400 mt-2">⭐ {product.rating} / 5</p>
      <Link to="/" className="mt-4 px-6 py-2 bg-blue-600 text-white rounded-lg shadow-md hover:bg-blue-700">العودة إلى المتجر</Link>
    </div>
  );
};

const Home = () => {
  const [selectedCategory, setSelectedCategory] = useState("جميع الأحذية");
  const [searchQuery, setSearchQuery] = useState("");

  const filteredProducts = products.filter(product => 
    (selectedCategory === "جميع الأحذية" || product.category === selectedCategory) &&
    product.name.includes(searchQuery)
  );

  return (
    <div className="min-h-screen bg-blue-900 text-white">
      <header className="bg-blue-800 shadow-md p-4 flex justify-between items-center">
        <h1 className="text-2xl font-bold text-blue-300">Special Step</h1>
        <div className="flex items-center gap-4">
          <input
            type="text"
            placeholder="ابحث عن حذاء..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="border px-2 py-1 rounded-md text-blue-900"
          />
          <FaSearch className="text-blue-300 cursor-pointer" size={20} />
          <FaShoppingCart className="text-blue-300 cursor-pointer" size={20} />
        </div>
      </header>

      <section className="bg-blue-700 text-white text-center py-16">
        <h2 className="text-4xl font-bold">أفضل الأحذية بأفضل الأسعار</h2>
        <p className="mt-2 text-lg">اكتشف مجموعتنا المميزة الآن</p>
      </section>

      <div className="flex justify-center gap-4 p-4">
        {categories.map(category => (
          <button
            key={category}
            className={`px-4 py-2 rounded-lg shadow-md ${selectedCategory === category ? "bg-blue-600 text-white" : "bg-blue-300 text-blue-900"}`}
            onClick={() => setSelectedCategory(category)}
          >
            {category}
          </button>
        ))}
      </div>

      <section className="p-6">
        <h3 className="text-2xl font-bold text-center mb-6">منتجاتنا</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {filteredProducts.map((product) => (
            <div key={product.id} className="bg-blue-800 p-4 rounded-lg shadow-md">
              <img src={product.image} alt={product.name} className="w-full h-48 object-cover rounded-md" />
              <h4 className="text-lg font-bold mt-2">{product.name}</h4>
              <p className="text-blue-300 font-semibold">{product.price}</p>
              <p className="text-blue-200 text-sm mt-1">{product.description}</p>
              <p className="text-yellow-400 text-sm">⭐ {product.rating} / 5</p>
              <Link to={`/product/${product.id}`} className="mt-2 px-4 py-2 bg-blue-600 text-white rounded-lg shadow-md hover:bg-blue-700 inline-block">
                تفاصيل المنتج
              </Link>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        {products.map(product => (
          <Route key={product.id} path={`/product/${product.id}`} element={<ProductDetails product={product} />} />
        ))}
      </Routes>
    </Router>
  );
};

export default App;
